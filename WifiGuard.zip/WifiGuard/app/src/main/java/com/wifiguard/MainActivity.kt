package com.wifiguard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { logView.text = LogStore.read(this@MainActivity); h.postDelayed(this, 2000) }
    }

    private fun btn(t: String, a: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { a() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(TextView(this).apply { text = "WifiGuard"; textSize = 26f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "Theo dõi ping, giữ Wi-Fi không ngủ, cảnh báo khi mất mạng."; setPadding(0, 8, 0, 16) })
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        root.addView(Switch(this).apply {
            text = "Tự động tắt/bật Wi-Fi khi mất mạng"
            isChecked = prefs.getBoolean("auto", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("auto", v).apply() }
        })
        root.addView(btn("▶ Bắt đầu theo dõi") {
            startForegroundService(Intent(this, MonitorService::class.java))
        })
        root.addView(btn("■ Dừng") {
            startService(Intent(this, MonitorService::class.java).setAction("STOP"))
        })
        root.addView(btn("📶 Mở bảng Wi-Fi (kết nối lại)") {
            startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        })
        root.addView(btn("🔋 Tắt tối ưu pin cho app") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("🗑 Xóa nhật ký") {
            LogStore.file(this).delete(); logView.text = LogStore.read(this)
        })
        logView = TextView(this).apply { textSize = 12f; typeface = Typeface.MONOSPACE; setPadding(0, 16, 0, 0) }
        root.addView(ScrollView(this).apply { addView(logView) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
