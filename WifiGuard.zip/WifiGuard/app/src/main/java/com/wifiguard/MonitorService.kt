package com.wifiguard

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.net.*
import android.net.wifi.WifiManager
import android.os.*
import java.io.File
import java.net.InetSocketAddress
import java.text.SimpleDateFormat
import java.util.*

object LogStore {
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
    fun file(c: Context) = File(c.filesDir, "log.txt")
    @Synchronized fun add(c: Context, msg: String) {
        val f = file(c)
        if (f.length() > 200_000) f.writeText(f.readLines().takeLast(1500).joinToString("\n") + "\n")
        f.appendText("${fmt.format(Date())}  $msg\n")
    }
    fun setStatus(c: Context, text: String) {
        File(c.filesDir, "status.txt").writeText("${System.currentTimeMillis()}\n$text")
    }
    fun readStatus(c: Context): String {
        val f = File(c.filesDir, "status.txt")
        if (!f.exists()) return "Chưa chạy. Bấm Bắt đầu theo dõi."
        val l = f.readLines()
        val age = (System.currentTimeMillis() - (l.getOrNull(0)?.toLongOrNull() ?: 0L)) / 1000
        val t = l.getOrNull(1) ?: ""
        return if (age > 15) "⚠ Không có cập nhật $age giây qua (app có thể đã bị đóng hoặc đã dừng)\nLần cuối: $t"
        else "✅ Đang chạy • $t"
    }
    fun read(c: Context): String {
        val f = file(c)
        if (!f.exists()) return "Chưa có dữ liệu."
        return f.readLines().takeLast(80).reversed().joinToString("\n")
    }
}

class MonitorService : Service() {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private lateinit var nm: NotificationManager
    private lateinit var cm: ConnectivityManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        cm = getSystemService(ConnectivityManager::class.java)
        nm.createNotificationChannel(NotificationChannel("status", "Trạng thái", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "Cảnh báo mất mạng", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun build(text: String, ch: String = "status"): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, ch)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("WifiGuard")
            .setContentText(text)
            .setContentIntent(pi)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startForeground(1, build("Đang theo dõi Wi-Fi..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!running) {
            running = true
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "WifiGuard").apply { acquire() }
            LogStore.add(this, "Bắt đầu theo dõi (đã khóa Wi-Fi chế độ độ trễ thấp)")
            thread = Thread { loop(wm) }.also { it.start() }
        }
        return START_STICKY
    }

    private fun wifiNetwork(): Network? = cm.allNetworks.firstOrNull {
        cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    private fun probe(net: Network?): Long {
        if (net == null) return -2
        return try {
            val s = net.socketFactory.createSocket()
            val t = SystemClock.elapsedRealtime()
            s.connect(InetSocketAddress("1.1.1.1", 443), 2000)
            val d = SystemClock.elapsedRealtime() - t
            s.close(); d
        } catch (e: Exception) { -1 }
    }

    private fun loop(wm: WifiManager) {
        var fails = 0
        var dropStart = 0L
        var weak = false
        var lastAttempt = 0L
        var lastBeat = 0L
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        while (running) {
            val net = wifiNetwork()
            val ms = probe(net)
            @Suppress("DEPRECATION") val rssi = try { wm.connectionInfo.rssi } catch (e: Exception) { -127 }
            val st = if (ms >= 0) "Ping $ms ms • sóng $rssi dBm" else "Đang mất mạng ($fails lần thử)"
            LogStore.setStatus(this, st)
            if (SystemClock.elapsedRealtime() - lastBeat > 600_000) {
                lastBeat = SystemClock.elapsedRealtime()
                LogStore.add(this, "Vẫn đang theo dõi: $st")
            }
            if (ms >= 0) {
                if (dropStart != 0L) {
                    val sec = (SystemClock.elapsedRealtime() - dropStart) / 1000
                    LogStore.add(this, "ĐÃ CÓ MẠNG LẠI sau $sec giây (sóng $rssi dBm)")
                    dropStart = 0L
                }
                fails = 0
                if (ms > 400) LogStore.add(this, "Độ trễ cao: $ms ms (sóng $rssi dBm)")
                nm.notify(1, build("Ping $ms ms • sóng $rssi dBm"))
            } else {
                fails++
                if (fails == 3 && dropStart == 0L) {
                    dropStart = SystemClock.elapsedRealtime() - 9000
                    val why = if (ms == -2L) "không kết nối Wi-Fi" else "Wi-Fi treo, không ra internet"
                    LogStore.add(this, "MẤT MẠNG: $why (sóng $rssi dBm)")
                    nm.notify(2, build("Mất mạng: $why. Mở ứng dụng để kết nối lại.", "alert"))
                }
            }
            if (fails >= 3 && prefs.getBoolean("auto", true) &&
                SystemClock.elapsedRealtime() - lastAttempt > 45000) {
                lastAttempt = SystemClock.elapsedRealtime()
                reconnect(wm)
                fails = 0
            }
            if (rssi > -127 && rssi < -75 && !weak) { weak = true; LogStore.add(this, "Sóng yếu: $rssi dBm") }
            if (rssi >= -70) weak = false
            try { Thread.sleep(3000) } catch (e: InterruptedException) { break }
        }
    }

    @Suppress("DEPRECATION")
    private fun reconnect(wm: WifiManager) {
        if (!wm.isWifiEnabled) { LogStore.add(this, "Wi-Fi đang tắt do bạn, bỏ qua tự kết nối lại"); return }
        LogStore.add(this, "Tự động tắt/bật Wi-Fi...")
        val off = wm.setWifiEnabled(false)
        try { Thread.sleep(2500) } catch (e: InterruptedException) { return }
        val on = wm.setWifiEnabled(true)
        if (!off && !on) {
            LogStore.add(this, "Hệ thống chặn việc tắt/bật Wi-Fi (trả về false)")
            nm.notify(2, build("Không tự tắt/bật Wi-Fi được. Hãy kết nối lại thủ công.", "alert"))
        } else LogStore.add(this, "Đã gửi lệnh bật lại Wi-Fi")
    }

    override fun onDestroy() {
        running = false
        thread?.interrupt()
        wifiLock?.let { if (it.isHeld) it.release() }
        LogStore.add(this, "Dừng theo dõi")
        LogStore.setStatus(this, "Đã dừng")
        super.onDestroy()
    }
}
